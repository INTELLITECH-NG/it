/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'it', {
	block: 'Giustifica',
	center: 'Centra',
	left: 'Allinea a sinistra',
	right: 'Allinea a destra'
} );
