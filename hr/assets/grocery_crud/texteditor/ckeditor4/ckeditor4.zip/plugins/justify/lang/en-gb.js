/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'en-gb', {
	block: 'Justify',
	center: 'Centre',
	left: 'Align Left',
	right: 'Align Right'
} );
